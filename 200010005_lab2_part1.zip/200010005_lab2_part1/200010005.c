#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

void printHello(char str[], int temp, int num) {
    if (temp < num) {
        int fork_pid = fork(), i = temp;
        if (fork_pid > 0)
        {
            printf("%c %d\n", str[i], fork_pid);
            sleep(1+rand()%4);
            printHello(str, i+1, num);
        }
    }
    return;
}
int main() {
    char helloText[] = "Hello World";
    printHello(helloText, 0, (sizeof(helloText) / sizeof(helloText[0])) - 1);
    return 0;
}