#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>

char *int_to_char(int val, int base)
{

    static char buf[32] = {0};
    int i = 30;
    for (; val && i; --i, val /= base)
        buf[i] = "0123456789abcdef"[val % base];
    return &buf[i + 1];
}

int main(int argc, char *argv[])
{
    if (argc == 1)
    {
        exit(0);
    }
    else
    {
        int pid = getpid();
        int int_parameter = atoi(argv[argc - 1]);
        int_parameter = int_parameter * 2;
        argv[argc - 1] = int_to_char(int_parameter, 10);
        printf("Twice: Current process id: %d, Current result: %s\n", pid, argv[argc - 1]);


        // memmove(&argv[0], &argv[1], (argc - 1) * sizeof(argv[0]));
        char *new_argv[argc];

        int i = 1;
        while (i <= argc)
        {
            new_argv[i - 1] = argv[i];
            i++;
            if (i == argc)
            {
                new_argv[i - 1] = NULL;
            }
        }

        // for (int i = 0; i < argc; i++)
        // {
        //     printf("%s \n", new_argv[i]);
        // }
        // printf("\n");

        execvp(new_argv[0], new_argv);
    }
    return 0;
}